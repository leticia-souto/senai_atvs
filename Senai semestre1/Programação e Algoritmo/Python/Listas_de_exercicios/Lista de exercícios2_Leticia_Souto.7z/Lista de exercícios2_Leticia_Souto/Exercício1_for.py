# -*- coding: UTF -8 -*-

print("Esse programa irá mostrar todos os números de 1 a 50 e os mesmos invertidos.")

for numeros in range (1, 51):
    print(numeros)
for numeros1 in range (50, 0, -1):
    print(numeros1)
