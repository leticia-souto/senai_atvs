# -*- coding: UTF -8 -*-

print("Esse programa irá imprimir a tabuada de 0 a 9")

numero = 0

for x in range (0,10):
    for m in range (1,11):
        print(f"{x}x{m} = {x*m}")
