# -*- coding: UTF -8 -*- 

 

print("Esse programa irá fazer uma contagem regressiva de 10 a 0.") 

 

def contagem_regressiva():
    for x in range (11,0,-1):
        x = x-1
        print(x)
    print("Feliz Natal!!") 

contagem_regressiva() 
