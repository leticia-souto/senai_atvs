#-*- coding: UTF-8 -*-
print("Escreva dois números inteiros que eu informarei qual é o maior")
valor1 = int(input("Digite o primeiro número"))
valor2 = int(input("Digite o segundo valor"))

if valor1 > valor2:
    print("O maior número é:", valor1)
else:
    print("O maior número é:", valor2)
