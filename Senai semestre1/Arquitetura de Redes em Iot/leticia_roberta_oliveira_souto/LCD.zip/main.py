from machine import I2C, Pin
from time import sleep
from pico_i2c_lcd import I2cLcd

# Configuração do barramento I2C nos pinos GP16 (SDA) e GP17 (SCL)
i2c = I2C(0, scl=Pin(16), sda=Pin(17), freq=400000)

# Descobre o endereço I2C automaticamente (geralmente é 0x27 ou 0x3F)
I2C_ADDR = i2c.scan()[0]

# Cria o objeto do display LCD com 2 linhas e 16 colunas
lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)

# Mensagem inicial
lcd.putstr("Testando o LCD")
sleep(2)
lcd.clear()

while True:
    lcd.clear()
    #coluna na ESQUERDA e linha na DIREITA
    lcd.move_to(1, 1)
    lcd.putstr(f"Olá Mundo!")
    lcd.move_to(0, 0)
    lcd.putstr(f"Tchau Mundo")
    sleep(2)