from machine import Pin
from utime import sleep

#vai ligar a lampada
rele = Pin(16, Pin.OUT)

#sensor que vai detectar a presença
presenca_pir = Pin(15, Pin.IN)

while True:
    #aqui vamos guardar o valor do PIR
    detectou = presenca_pir.value()
    #se detectar, liga lampada (o rele liga ela)
    if detectou == 1:
        rele.on()
        print("Detectou")
    else:
        rele.off()
        detectou = 0
        print("Não detectou nada")

    sleep(0.005)