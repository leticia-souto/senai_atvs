from machine import Pin
from utime import sleep
from dht import DHT22

sensor_t = DHT22(Pin(15))
led_atencao = Pin(18, Pin.OUT)

while True:
    sensor_t.measure()
    temperatura = sensor_t.temperature()
    umidade = sensor_t.humidity()
    
    if temperatura > 30:
        print("ALERTA! Temperatura muito alta!")
        led_atencao.on()
        sleep(1)

    else:
        print(f"A temperatura atual é {temperatura}°C")
        print(f"A umidade atual é {umidade}%")
        led_atencao.off()
    sleep(2)